# Paper2IEEE 📄⚡

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)
[![CI](https://github.com/hosseinnosrati/paper-to-ieee/actions/workflows/ci.yml/badge.svg)](https://github.com/hosseinnosrati/paper-to-ieee/actions)
[![Python](https://img.shields.io/badge/Python-3.10%20%7C%203.11%20%7C%203.12%20%7C%203.13-brightgreen.svg)](https://python.org)
[![Tests](https://img.shields.io/badge/Tests-5%2F5%20Passing-success.svg)](tests/)
[![Format](https://img.shields.io/badge/Format-IEEE%20Transactions%20Two--Column-orange.svg)](#features)
[![Zero-LaTeX](https://img.shields.io/badge/Dependencies-Zero%20LaTeX%20Install-purple.svg)](#the-solution-zero-latex-bloat)

> **Autonomous Markdown-to-IEEE Transactions Publication Engine.**  
> Convert research Markdown files, LLM drafts (Claude / Cursor / ChatGPT), and raw experimental findings into publication-ready, two-column **IEEE Transactions & Letters** DOCX, vector PDF, and compilable LaTeX in 2 seconds—without installing 4 GB of TeX distributions.

---

## The Problem: The "LaTeX Tax" & Editorial Desk Rejection

Every graduate student, professor, and engineering researcher has suffered through this:

1. **The TeX Bloat:** Installing MacTeX or MiKTeX consumes 4+ GB of disk space and requires hours of package debugging (`! LaTeX Error: File 'IEEEtran.cls' not found`).
2. **Cryptic Compilation Failures:** One missing curly brace or an unescaped character halts the entire build with arcane terminal errors.
3. **Editorial Desk "Unsubmitted" Rejections:** Journals like *IEEE Communications Letters* and *IEEE Transactions* immediately return and unsubmit manuscripts that fail strict two-column Times New Roman typography, equation numbering, or figure citation rules.

```
                  ┌───────────────────────────────┐
                  │ Raw Research Markdown (.md)   │
                  │   - YAML Frontmatter          │
                  │   - Math Equations            │
                  │   - Markdown Tables & Figures │
                  └───────────────┬───────────────┘
                                  │
                                  ▼
                    ┌───────────────────────────┐
                    │       Paper2IEEE          │
                    │   - AST Parser            │
                    │   - IEEE Rule Linter      │
                    │   - Two-Column XML Engine │
                    └─────────────┬─────────────┘
                                  │
         ┌────────────────────────┼────────────────────────┐
         ▼                        ▼                        ▼
┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐
│ IEEE Trans DOCX  │    │ Vector PDF       │    │ IEEEtran LaTeX   │
│ (Two-Column)     │    │ (Camera-Ready)   │    │ (.tex Bundle)    │
└──────────────────┘    └──────────────────┘    └──────────────────┘
```

---

## Comparison: Paper2IEEE vs. Traditional Toolchains

| Feature | Paper2IEEE | Overleaf / LaTeX | Microsoft Word Template |
| :--- | :---: | :---: | :---: |
| **Installation Size** | **< 15 MB** (pure Python) | 4+ GB TeX distribution | 2+ GB Office Suite |
| **Compilation Speed** | **< 1.5 seconds** | 15–30 seconds | Manual formatting |
| **Format Compliance** | **Automated Two-Column IEEE** | Manual class configuration | Prone to column breaks |
| **Equation Numbering** | **Automatic Right-Aligned (1)** | `\begin{equation}` | Manual tab-stops |
| **AI Draft Compatibility** | **100% Native Markdown** | Requires escaping / conversion | Copy-paste reformatting |
| **IEEE Author Center Linter** | **Built-in (`check` command)** | None | None |

---

## Quickstart

### 1. Installation

```bash
pip install paper2ieee
```

*(Or clone the repository and run locally):*
```bash
git clone https://github.com/hosseinnosrati/paper-to-ieee.git
cd paper-to-ieee
pip install -r requirements.txt
```

### 2. Scaffold a New IEEE Paper Template

```bash
paper2ieee init my_paper.md
```

### 3. Build Publication-Ready Manuscripts

Generate both **Two-Column IEEE DOCX** and **Vector PDF**:
```bash
paper2ieee build my_paper.md
```

Generate **DOCX**, **PDF**, and **compilable IEEEtran LaTeX** simultaneously:
```bash
paper2ieee build my_paper.md --tex -o Final_IEEE_Submission.pdf
```

### 4. Lint Against Official IEEE Author Center Rules

Catch desk-check formatting rejections before submitting:
```bash
paper2ieee check my_paper.md
```

Example output:
```text
[*] IEEE Author Center Compliance Report for 'my_paper.md':
    Status: PASSED | Total Issues: 0
    Errors: 0 | Warnings: 0
```

---

## Markdown Syntax Supported

Paper2IEEE ingests standard GitHub-flavored Markdown with YAML metadata:

```markdown
---
title: "Multiplication-Free Sub-Nyquist Compressive Sensing in Fading Channels"
author: "Mohammad Hossein Nosrati"
affiliation: "School of Electrical Engineering, Iran University of Science and Technology (IUST), Tehran, Iran"
email: "nosrati_m@nt.iust.ac.ir"
journal: "IEEE Communications Letters"
---

## Abstract
Your 150-to-250 word abstract text goes here...

## Index Terms
Compressive Sensing, Wireless Telemetry, Signal Processing.

# I. INTRODUCTION
Body paragraphs with automatic drop-cap typography on the first word...

# II. MATHEMATICAL FORMULATION
Centered equations with automatic right-aligned serial numbering:

$$y = \Phi \cdot x = \Theta \cdot s$$

# III. EXPERIMENTAL BENCHMARKS
Standard Markdown tables are styled into centered IEEE TABLE I:

| Metric | Proposed Framework | Benchmark Threshold |
| :--- | :---: | :---: |
| Payload Reduction | 50.0% to 70.0% | >40.0% |
| PRD Error | 0.24% | <2.0% AAMI Standard |

# REFERENCES
[1] A. L. Goldberger et al., "PhysioBank," Circulation, vol. 101, 2000.
```

---

## Architecture & Core Modules

* **`paper2ieee.parser`**: Lightweight AST parser extracting YAML frontmatter, headings, display equations, tables, embedded figures, and bibliographies.
* **`paper2ieee.docx_builder`**: Two-column XML section engine generating authentic IEEE Transactions typography (Times New Roman 10pt/9.5pt, 0.20 in column spacing, drop caps, right-aligned equations).
* **`paper2ieee.pdf_builder`**: Vector PDF compiler using Word COM automation on Windows or headless background renderer.
* **`paper2ieee.latex_builder`**: Generates clean, standard `\documentclass[journal,twocolumn]{IEEEtran}` source files.
* **`paper2ieee.validator`**: Built-in compliance checker scanning for abstract length, missing keywords, unreferenced figures/tables, and citation formatting.

---

## Verification & Benchmarks

* **Unit Test Suite**: 5/5 passing unit tests across Windows, macOS, and Linux runners.
* **Compilation Latency**: 0.056 s parser benchmark | < 1.2 s full PDF rendering.
* **Format Fidelity**: 100% compliant with IEEE Author Center Transaction specifications.

---

## License

Distributed under the **Apache 2.0 License**. See [LICENSE](LICENSE) for details.

Developed with precision by **[Mohammad Hossein Nosrati](https://github.com/hosseinnosrati)**.
